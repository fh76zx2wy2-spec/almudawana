import { defineConfig } from 'vite';
export default defineConfig({base:'/almudawana/',build:{target:'es2022',assetsDir:''}});
