export const ZONE='Asia/Riyadh';
export const today=()=>new Intl.DateTimeFormat('en-CA',{timeZone:ZONE,year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
export const asDate=s=>new Date(s.slice(0,10)+'T12:00:00+03:00');
export const shift=(s,n)=>{let d=asDate(s);d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10)};
export function parts(s,calendar='islamic-umalqura'){return Object.fromEntries(new Intl.DateTimeFormat('en-u-nu-latn',{calendar,timeZone:ZONE,year:'numeric',month:'numeric',day:'numeric'}).formatToParts(asDate(s)).filter(x=>x.type!=='literal').map(x=>[x.type,Number(x.value)]))}
export function dateLabel(s,calendar='islamic-umalqura',opts={}){return new Intl.DateTimeFormat('ar-SA',{calendar,timeZone:ZONE,day:'numeric',month:'long',year:'numeric',...opts}).format(asDate(s))}
export function range(anchor,view,calendar='islamic-umalqura'){
 if(view==='day')return [anchor];
 if(view==='week'){let dow=asDate(anchor).getUTCDay(),start=shift(anchor,-((dow+1)%7));return Array.from({length:7},(_,i)=>shift(start,i))}
 const p=parts(anchor,calendar); let start=anchor;for(let i=0;i<370;i++){let prev=shift(start,-1),q=parts(prev,calendar);if(q.year!==p.year||(view==='month'&&q.month!==p.month))break;start=prev}
 let out=[];for(let i=0;i<370;i++){let d=shift(start,i),q=parts(d,calendar);if(q.year!==p.year||(view==='month'&&q.month!==p.month))break;out.push(d)}return out;
}
export function move(anchor,view,calendar,direction){const days=range(anchor,view,calendar);return direction>0?shift(days.at(-1),1):shift(days[0],-1)}
export const escapeHTML=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const splitItems=text=>text.split(/[\n،,]+/).map(x=>x.trim()).filter(Boolean).slice(0,100);
