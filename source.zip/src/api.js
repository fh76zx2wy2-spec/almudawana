import {createClient} from '@supabase/supabase-js';
const url=import.meta.env.VITE_SUPABASE_URL,key=import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
export const db=url&&key?createClient(url,key,{auth:{storage:sessionStorage,persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}}):null;
export async function rows(table){const {data,error}=await db.from(table).select('*');if(error)throw error;return data}
export async function insert(table,payload){const {data,error}=await db.from(table).insert(payload).select();if(error)throw error;return data}
export async function update(table,id,payload){const {data,error}=await db.from(table).update(payload).eq('id',id).select();if(error)throw error;if(!data.length)throw new Error('لم يتم الحفظ. ربما تغيّرت الصلاحيات؛ حدّث الصفحة.');return data}
