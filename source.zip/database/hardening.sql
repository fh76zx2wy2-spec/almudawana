-- Target: the existing almudawana database only. Review and test transactionally.
BEGIN;
CREATE SCHEMA IF NOT EXISTS app_private;
REVOKE ALL ON SCHEMA app_private FROM PUBLIC, anon;
GRANT USAGE ON SCHEMA app_private TO authenticated;
CREATE OR REPLACE FUNCTION app_private.is_member()
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path='' AS $$
 SELECT auth.uid() IS NOT NULL AND EXISTS (
  SELECT 1 FROM public.pair_members m JOIN auth.users u ON u.id=m.user_id
  JOIN public.allowed_emails a ON a.email=lower(u.email)
  WHERE m.user_id=auth.uid() AND u.email_confirmed_at IS NOT NULL
 );
$$;
REVOKE ALL ON FUNCTION app_private.is_member() FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION app_private.is_member() TO authenticated;
DO $$ DECLARE t text; BEGIN
 FOREACH t IN ARRAY ARRAY['profiles','pair_members','notes','note_comments','note_reactions','note_updates','task_lists','tasks','task_events','gentle_requests','notifications'] LOOP
  EXECUTE format('CREATE POLICY active_member_gate ON public.%I AS RESTRICTIVE FOR ALL TO authenticated USING (app_private.is_member()) WITH CHECK (app_private.is_member())',t);
 END LOOP;
END $$;
CREATE OR REPLACE FUNCTION public.enforce_allowlist()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
BEGIN
 IF NEW.email IS NULL OR NOT EXISTS(SELECT 1 FROM public.allowed_emails WHERE email=lower(NEW.email)) THEN RAISE EXCEPTION 'email_not_allowed'; END IF;
 IF TG_OP='UPDATE' AND lower(NEW.email) IS DISTINCT FROM lower(OLD.email) THEN RAISE EXCEPTION 'email_is_fixed'; END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER enforce_allowlist_before_update BEFORE UPDATE OF email ON auth.users FOR EACH ROW EXECUTE FUNCTION public.enforce_allowlist();
-- Only read state is client-mutable on notifications.
REVOKE UPDATE ON public.notifications FROM authenticated;
GRANT UPDATE(read_at) ON public.notifications TO authenticated;
REVOKE UPDATE ON public.gentle_requests FROM authenticated;
GRANT UPDATE(status,reply) ON public.gentle_requests TO authenticated;
REVOKE UPDATE ON public.profiles FROM authenticated;
GRANT UPDATE(display_name,gender) ON public.profiles TO authenticated;
CREATE OR REPLACE FUNCTION public.tasks_validate()
RETURNS trigger LANGUAGE plpgsql SET search_path='' AS $$
BEGIN
 IF TG_OP='UPDATE' AND NEW.list_id IS DISTINCT FROM OLD.list_id THEN RAISE EXCEPTION 'list_id is immutable'; END IF;
 IF NEW.assignee_id IS NOT NULL AND NEW.assignee_id<>auth.uid() AND NEW.assignee_id IS DISTINCT FROM public.my_partner() THEN RAISE EXCEPTION 'invalid assignee'; END IF;
 IF NEW.is_done AND (TG_OP='INSERT' OR NOT OLD.is_done) THEN NEW.done_by:=auth.uid(); NEW.done_at:=now();
 ELSIF NOT NEW.is_done THEN NEW.done_by:=NULL; NEW.done_at:=NULL; END IF;
 RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION public.notes_notify()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
BEGIN
 IF NOT NEW.is_shared OR NEW.status<>'published' OR NEW.deleted_at IS NOT NULL THEN
  DELETE FROM public.notifications WHERE entity_type='note' AND entity_id=NEW.id;
 ELSIF TG_OP='INSERT' OR NOT (OLD.is_shared AND OLD.status='published' AND OLD.deleted_at IS NULL) THEN
  PERFORM public._notify_partner('note_shared','note',NEW.id,'');
 END IF;
 RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION public.note_social_notify()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE n public.notes; k text;
BEGIN
 SELECT * INTO n FROM public.notes WHERE id=NEW.note_id;
 IF n.id IS NULL OR NOT n.is_shared OR n.status<>'published' OR n.deleted_at IS NOT NULL THEN RETURN NEW; END IF;
 IF TG_TABLE_NAME='note_reactions' THEN k:='note_reaction'; ELSE k:='note_comment'; END IF;
 PERFORM public._notify_partner(k,'note',n.id,''); RETURN NEW;
END $$;
-- Prevent future large binary strings being used as attachments. Product contains text fields only.
ALTER TABLE public.notes ADD CONSTRAINT notes_text_limits CHECK(char_length(title)<=200 AND char_length(body)<=20000 AND (mood IS NULL OR char_length(mood)<=30) AND template IN ('paper','sage','gold'));
-- Clear historical note title copies; unread notifications never retain private journal text.
UPDATE public.notifications SET entity_title='' WHERE entity_type='note';
REVOKE EXECUTE ON FUNCTION public.touch_updated_at(),public.lock_owner(),public.tasks_validate(),public.gentle_requests_guard() FROM PUBLIC,anon;
COMMIT;
