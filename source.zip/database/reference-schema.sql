
-- ===== Allowlist (no client access at all) =====
CREATE TABLE public.allowed_emails (
  email text PRIMARY KEY CHECK (email = lower(email)),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.allowed_emails TO service_role;
ALTER TABLE public.allowed_emails ENABLE ROW LEVEL SECURITY;
-- no policies: invisible to anon/authenticated

-- ===== Pair =====
CREATE TABLE public.pairs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.pairs TO service_role;
ALTER TABLE public.pairs ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.pair_members (
  user_id uuid PRIMARY KEY,
  pair_id uuid NOT NULL REFERENCES public.pairs(id) ON DELETE CASCADE,
  joined_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX pair_members_pair_idx ON public.pair_members(pair_id);
GRANT SELECT ON public.pair_members TO authenticated;
GRANT ALL ON public.pair_members TO service_role;
ALTER TABLE public.pair_members ENABLE ROW LEVEL SECURITY;

-- Security definer is required here to avoid RLS recursion on pair_members.
-- It only ever returns the partner of the calling user (auth.uid()).
CREATE OR REPLACE FUNCTION public.my_partner()
RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT m2.user_id FROM public.pair_members m1
  JOIN public.pair_members m2 ON m2.pair_id = m1.pair_id AND m2.user_id <> m1.user_id
  WHERE m1.user_id = auth.uid() LIMIT 1
$$;
REVOKE ALL ON FUNCTION public.my_partner() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.my_partner() TO authenticated;

CREATE POLICY "see own and partner membership" ON public.pair_members FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR user_id = public.my_partner());

-- ===== Profiles =====
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name text NOT NULL DEFAULT '' CHECK (char_length(display_name) <= 40),
  gender text CHECK (gender IN ('m','f')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read self or partner" ON public.profiles FOR SELECT TO authenticated
  USING (id = auth.uid() OR id = public.my_partner());
CREATE POLICY "update self" ON public.profiles FOR UPDATE TO authenticated
  USING (id = auth.uid()) WITH CHECK (id = auth.uid());

-- ===== Signup gate on auth.users (security definer: must read the hidden allowlist) =====
CREATE OR REPLACE FUNCTION public.enforce_allowlist()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.email IS NULL OR NOT EXISTS (SELECT 1 FROM public.allowed_emails WHERE email = lower(NEW.email)) THEN
    RAISE EXCEPTION 'email_not_allowed';
  END IF;
  RETURN NEW;
END $$;
REVOKE ALL ON FUNCTION public.enforce_allowlist() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER enforce_allowlist_before_insert BEFORE INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.enforce_allowlist();

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _pair uuid; _n int;
BEGIN
  INSERT INTO public.profiles(id, display_name) VALUES (NEW.id, split_part(NEW.email, '@', 1))
  ON CONFLICT (id) DO NOTHING;
  SELECT id INTO _pair FROM public.pairs ORDER BY created_at LIMIT 1;
  IF _pair IS NULL THEN
    INSERT INTO public.pairs DEFAULT VALUES RETURNING id INTO _pair;
  END IF;
  SELECT count(*) INTO _n FROM public.pair_members WHERE pair_id = _pair;
  IF _n < 2 THEN
    INSERT INTO public.pair_members(user_id, pair_id) VALUES (NEW.id, _pair) ON CONFLICT DO NOTHING;
  END IF;
  RETURN NEW;
END $$;
REVOKE ALL ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ===== Generic helpers =====
CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END $$;

CREATE OR REPLACE FUNCTION public.lock_owner()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF NEW.owner_id IS DISTINCT FROM OLD.owner_id THEN RAISE EXCEPTION 'owner_id is immutable'; END IF;
  RETURN NEW;
END $$;

CREATE TRIGGER profiles_touch BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- ===== Notifications =====
CREATE TABLE public.notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient_id uuid NOT NULL,
  actor_id uuid NOT NULL,
  kind text NOT NULL,
  entity_type text NOT NULL,
  entity_id uuid NOT NULL,
  entity_title text NOT NULL DEFAULT '',
  count int NOT NULL DEFAULT 1,
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX notifications_recipient_idx ON public.notifications(recipient_id, updated_at DESC);
GRANT SELECT, UPDATE, DELETE ON public.notifications TO authenticated;
GRANT ALL ON public.notifications TO service_role;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "recipient reads" ON public.notifications FOR SELECT TO authenticated USING (recipient_id = auth.uid());
CREATE POLICY "recipient marks" ON public.notifications FOR UPDATE TO authenticated USING (recipient_id = auth.uid()) WITH CHECK (recipient_id = auth.uid());
CREATE POLICY "recipient deletes" ON public.notifications FOR DELETE TO authenticated USING (recipient_id = auth.uid());

-- internal: only callable from trigger functions (no grants to app roles)
CREATE OR REPLACE FUNCTION public._notify_partner(_kind text, _etype text, _eid uuid, _etitle text, _inc int DEFAULT 1)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _r uuid := public.my_partner(); _me uuid := auth.uid();
BEGIN
  IF _r IS NULL OR _me IS NULL THEN RETURN; END IF;
  UPDATE public.notifications SET count = count + _inc, updated_at = now(), entity_title = coalesce(_etitle, entity_title)
   WHERE recipient_id = _r AND actor_id = _me AND kind = _kind AND entity_id = _eid
     AND read_at IS NULL AND updated_at > now() - interval '3 hours';
  IF NOT FOUND THEN
    INSERT INTO public.notifications(recipient_id, actor_id, kind, entity_type, entity_id, entity_title, count)
    VALUES (_r, _me, _kind, _etype, _eid, coalesce(_etitle, ''), _inc);
  END IF;
END $$;
REVOKE ALL ON FUNCTION public._notify_partner(text, text, uuid, text, int) FROM PUBLIC, anon, authenticated;

-- ===== Notes =====
CREATE TABLE public.notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL DEFAULT auth.uid(),
  title text NOT NULL DEFAULT '',
  body text NOT NULL DEFAULT '',
  mood text,
  mood_color text,
  best_moment text,
  gratitude text,
  quote text,
  category text,
  tags text[] NOT NULL DEFAULT '{}',
  note_date date NOT NULL DEFAULT (now() AT TIME ZONE 'Asia/Riyadh')::date,
  template text NOT NULL DEFAULT 'paper',
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published')),
  is_shared boolean NOT NULL DEFAULT false,
  is_milestone boolean NOT NULL DEFAULT false,
  deleted_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX notes_owner_date_idx ON public.notes(owner_id, note_date DESC);
CREATE INDEX notes_shared_idx ON public.notes(is_shared) WHERE is_shared;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.notes TO authenticated;
GRANT ALL ON public.notes TO service_role;
ALTER TABLE public.notes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "owner or shared-with-partner reads" ON public.notes FOR SELECT TO authenticated
  USING (owner_id = auth.uid() OR (is_shared AND deleted_at IS NULL AND status = 'published' AND owner_id = public.my_partner()));
CREATE POLICY "owner inserts" ON public.notes FOR INSERT TO authenticated WITH CHECK (owner_id = auth.uid());
CREATE POLICY "owner updates" ON public.notes FOR UPDATE TO authenticated USING (owner_id = auth.uid()) WITH CHECK (owner_id = auth.uid());
CREATE POLICY "owner deletes" ON public.notes FOR DELETE TO authenticated USING (owner_id = auth.uid());
CREATE TRIGGER notes_touch BEFORE UPDATE ON public.notes FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER notes_lock_owner BEFORE UPDATE ON public.notes FOR EACH ROW EXECUTE FUNCTION public.lock_owner();

CREATE OR REPLACE FUNCTION public.notes_notify()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.is_shared AND NEW.status = 'published' AND NEW.deleted_at IS NULL
     AND (TG_OP = 'INSERT' OR NOT (OLD.is_shared AND OLD.status = 'published' AND OLD.deleted_at IS NULL)) THEN
    PERFORM public._notify_partner('note_shared', 'note', NEW.id, nullif(NEW.title, ''));
  END IF;
  RETURN NEW;
END $$;
REVOKE ALL ON FUNCTION public.notes_notify() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER notes_notify_trg AFTER INSERT OR UPDATE ON public.notes FOR EACH ROW EXECUTE FUNCTION public.notes_notify();

-- comments + "تفصيل أتذكره"
CREATE TABLE public.note_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  note_id uuid NOT NULL REFERENCES public.notes(id) ON DELETE CASCADE,
  author_id uuid NOT NULL DEFAULT auth.uid(),
  kind text NOT NULL DEFAULT 'comment' CHECK (kind IN ('comment','memory')),
  body text NOT NULL CHECK (char_length(body) BETWEEN 1 AND 4000),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX note_comments_note_idx ON public.note_comments(note_id, created_at);
GRANT SELECT, INSERT, DELETE ON public.note_comments TO authenticated;
GRANT ALL ON public.note_comments TO service_role;
ALTER TABLE public.note_comments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read if note visible" ON public.note_comments FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.notes n WHERE n.id = note_id));
CREATE POLICY "write if note visible" ON public.note_comments FOR INSERT TO authenticated
  WITH CHECK (author_id = auth.uid() AND EXISTS (SELECT 1 FROM public.notes n WHERE n.id = note_id AND n.deleted_at IS NULL));
CREATE POLICY "author deletes" ON public.note_comments FOR DELETE TO authenticated USING (author_id = auth.uid());

CREATE TABLE public.note_reactions (
  note_id uuid NOT NULL REFERENCES public.notes(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (note_id, user_id)
);
GRANT SELECT, INSERT, DELETE ON public.note_reactions TO authenticated;
GRANT ALL ON public.note_reactions TO service_role;
ALTER TABLE public.note_reactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read if note visible" ON public.note_reactions FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.notes n WHERE n.id = note_id));
CREATE POLICY "react if note visible" ON public.note_reactions FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid() AND EXISTS (SELECT 1 FROM public.notes n WHERE n.id = note_id));
CREATE POLICY "unreact own" ON public.note_reactions FOR DELETE TO authenticated USING (user_id = auth.uid());

-- حديث مع الماضي: owner-only dated additions
CREATE TABLE public.note_updates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  note_id uuid NOT NULL REFERENCES public.notes(id) ON DELETE CASCADE,
  author_id uuid NOT NULL DEFAULT auth.uid(),
  body text NOT NULL CHECK (char_length(body) BETWEEN 1 AND 8000),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX note_updates_note_idx ON public.note_updates(note_id, created_at);
GRANT SELECT, INSERT, DELETE ON public.note_updates TO authenticated;
GRANT ALL ON public.note_updates TO service_role;
ALTER TABLE public.note_updates ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read if note visible" ON public.note_updates FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.notes n WHERE n.id = note_id));
CREATE POLICY "owner adds" ON public.note_updates FOR INSERT TO authenticated
  WITH CHECK (author_id = auth.uid() AND EXISTS (SELECT 1 FROM public.notes n WHERE n.id = note_id AND n.owner_id = auth.uid()));
CREATE POLICY "owner removes" ON public.note_updates FOR DELETE TO authenticated USING (author_id = auth.uid());

CREATE OR REPLACE FUNCTION public.note_social_notify()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _n public.notes;
BEGIN
  SELECT * INTO _n FROM public.notes WHERE id = NEW.note_id;
  IF _n.id IS NULL OR NOT _n.is_shared THEN RETURN NEW; END IF;
  IF TG_TABLE_NAME = 'note_reactions' THEN
    PERFORM public._notify_partner('note_reaction', 'note', _n.id, nullif(_n.title, ''));
  ELSIF NEW.kind = 'memory' THEN
    PERFORM public._notify_partner('note_memory', 'note', _n.id, nullif(_n.title, ''));
  ELSE
    PERFORM public._notify_partner('note_comment', 'note', _n.id, nullif(_n.title, ''));
  END IF;
  RETURN NEW;
END $$;
REVOKE ALL ON FUNCTION public.note_social_notify() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER note_comments_notify AFTER INSERT ON public.note_comments FOR EACH ROW EXECUTE FUNCTION public.note_social_notify();
CREATE TRIGGER note_reactions_notify AFTER INSERT ON public.note_reactions FOR EACH ROW EXECUTE FUNCTION public.note_social_notify();

-- ===== Task lists & tasks =====
CREATE TABLE public.task_lists (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL DEFAULT auth.uid(),
  name text NOT NULL CHECK (char_length(name) BETWEEN 1 AND 80),
  kind text NOT NULL DEFAULT 'general' CHECK (kind IN ('general','groceries','pharmacy','travel','home','wishes')),
  is_shared boolean NOT NULL DEFAULT false,
  archived boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX task_lists_owner_idx ON public.task_lists(owner_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.task_lists TO authenticated;
GRANT ALL ON public.task_lists TO service_role;
ALTER TABLE public.task_lists ENABLE ROW LEVEL SECURITY;
CREATE POLICY "owner or shared reads" ON public.task_lists FOR SELECT TO authenticated
  USING (owner_id = auth.uid() OR (is_shared AND owner_id = public.my_partner()));
CREATE POLICY "owner inserts" ON public.task_lists FOR INSERT TO authenticated WITH CHECK (owner_id = auth.uid());
CREATE POLICY "owner updates" ON public.task_lists FOR UPDATE TO authenticated USING (owner_id = auth.uid()) WITH CHECK (owner_id = auth.uid());
CREATE POLICY "owner deletes" ON public.task_lists FOR DELETE TO authenticated USING (owner_id = auth.uid());
CREATE TRIGGER task_lists_touch BEFORE UPDATE ON public.task_lists FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER task_lists_lock_owner BEFORE UPDATE ON public.task_lists FOR EACH ROW EXECUTE FUNCTION public.lock_owner();

CREATE OR REPLACE FUNCTION public.task_lists_notify()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.is_shared AND (TG_OP = 'INSERT' OR NOT OLD.is_shared) THEN
    PERFORM public._notify_partner('list_shared', 'list', NEW.id, NEW.name);
  END IF;
  RETURN NEW;
END $$;
REVOKE ALL ON FUNCTION public.task_lists_notify() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER task_lists_notify_trg AFTER INSERT OR UPDATE ON public.task_lists FOR EACH ROW EXECUTE FUNCTION public.task_lists_notify();

CREATE TABLE public.tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  list_id uuid NOT NULL REFERENCES public.task_lists(id) ON DELETE CASCADE,
  owner_id uuid NOT NULL DEFAULT auth.uid(),
  title text NOT NULL CHECK (char_length(title) BETWEEN 1 AND 200),
  quantity text,
  notes text,
  is_done boolean NOT NULL DEFAULT false,
  done_by uuid,
  done_at timestamptz,
  assignee_id uuid,
  priority smallint NOT NULL DEFAULT 0 CHECK (priority BETWEEN 0 AND 2),
  due_date date,
  remind_at timestamptz,
  sort_order double precision NOT NULL DEFAULT extract(epoch from now()),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX tasks_list_idx ON public.tasks(list_id, is_done, sort_order);
CREATE INDEX tasks_due_idx ON public.tasks(due_date) WHERE due_date IS NOT NULL;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.tasks TO authenticated;
GRANT ALL ON public.tasks TO service_role;
ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read via visible list" ON public.tasks FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.task_lists l WHERE l.id = list_id));
CREATE POLICY "insert via visible list" ON public.tasks FOR INSERT TO authenticated
  WITH CHECK (owner_id = auth.uid() AND EXISTS (SELECT 1 FROM public.task_lists l WHERE l.id = list_id));
CREATE POLICY "update via visible list" ON public.tasks FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.task_lists l WHERE l.id = list_id))
  WITH CHECK (EXISTS (SELECT 1 FROM public.task_lists l WHERE l.id = list_id));
CREATE POLICY "delete via visible list" ON public.tasks FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.task_lists l WHERE l.id = list_id));
CREATE TRIGGER tasks_touch BEFORE UPDATE ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER tasks_lock_owner BEFORE UPDATE ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.lock_owner();

CREATE OR REPLACE FUNCTION public.tasks_validate()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF NEW.assignee_id IS NOT NULL AND NEW.assignee_id <> auth.uid() AND NEW.assignee_id IS DISTINCT FROM public.my_partner() THEN
    RAISE EXCEPTION 'assignee must be you or your partner';
  END IF;
  IF NEW.is_done AND (TG_OP = 'INSERT' OR NOT OLD.is_done) THEN
    NEW.done_by := auth.uid(); NEW.done_at := now();
  ELSIF NOT NEW.is_done THEN
    NEW.done_by := NULL; NEW.done_at := NULL;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER tasks_validate_trg BEFORE INSERT OR UPDATE ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.tasks_validate();

-- short change log
CREATE TABLE public.task_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  list_id uuid NOT NULL REFERENCES public.task_lists(id) ON DELETE CASCADE,
  actor_id uuid NOT NULL,
  action text NOT NULL,
  detail text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX task_events_list_idx ON public.task_events(list_id, created_at DESC);
GRANT SELECT ON public.task_events TO authenticated;
GRANT ALL ON public.task_events TO service_role;
ALTER TABLE public.task_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read via visible list" ON public.task_events FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.task_lists l WHERE l.id = list_id));

CREATE OR REPLACE FUNCTION public.tasks_after()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _l public.task_lists; _rec public.tasks;
BEGIN
  _rec := CASE WHEN TG_OP = 'DELETE' THEN OLD ELSE NEW END;
  SELECT * INTO _l FROM public.task_lists WHERE id = _rec.list_id;
  IF _l.id IS NULL OR auth.uid() IS NULL THEN RETURN NULL; END IF;
  IF TG_OP = 'INSERT' THEN
    INSERT INTO public.task_events(list_id, actor_id, action, detail) VALUES (_l.id, auth.uid(), 'added', NEW.title);
    IF _l.is_shared THEN PERFORM public._notify_partner('items_added', 'list', _l.id, _l.name); END IF;
  ELSIF TG_OP = 'UPDATE' THEN
    IF NEW.is_done AND NOT OLD.is_done THEN
      INSERT INTO public.task_events(list_id, actor_id, action, detail) VALUES (_l.id, auth.uid(), 'done', NEW.title);
      IF _l.is_shared THEN PERFORM public._notify_partner('task_done', 'list', _l.id, _l.name); END IF;
    ELSIF OLD.is_done AND NOT NEW.is_done THEN
      INSERT INTO public.task_events(list_id, actor_id, action, detail) VALUES (_l.id, auth.uid(), 'reopened', NEW.title);
    END IF;
  ELSE
    INSERT INTO public.task_events(list_id, actor_id, action, detail) VALUES (_l.id, auth.uid(), 'removed', OLD.title);
  END IF;
  RETURN NULL;
END $$;
REVOKE ALL ON FUNCTION public.tasks_after() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER tasks_after_trg AFTER INSERT OR UPDATE OR DELETE ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.tasks_after();

-- ===== Gentle requests (طلب لطيف) =====
CREATE TABLE public.gentle_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  from_id uuid NOT NULL DEFAULT auth.uid(),
  to_id uuid NOT NULL,
  body text NOT NULL CHECK (char_length(body) BETWEEN 1 AND 500),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','ok','later','done')),
  reply text CHECK (reply IS NULL OR char_length(reply) <= 500),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX gentle_requests_to_idx ON public.gentle_requests(to_id, created_at DESC);
CREATE INDEX gentle_requests_from_idx ON public.gentle_requests(from_id, created_at DESC);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.gentle_requests TO authenticated;
GRANT ALL ON public.gentle_requests TO service_role;
ALTER TABLE public.gentle_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "parties read" ON public.gentle_requests FOR SELECT TO authenticated USING (from_id = auth.uid() OR to_id = auth.uid());
CREATE POLICY "send to partner" ON public.gentle_requests FOR INSERT TO authenticated
  WITH CHECK (from_id = auth.uid() AND to_id = public.my_partner());
CREATE POLICY "recipient responds" ON public.gentle_requests FOR UPDATE TO authenticated
  USING (to_id = auth.uid()) WITH CHECK (to_id = auth.uid());
CREATE POLICY "sender deletes" ON public.gentle_requests FOR DELETE TO authenticated USING (from_id = auth.uid());

CREATE OR REPLACE FUNCTION public.gentle_requests_guard()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF NEW.from_id <> OLD.from_id OR NEW.to_id <> OLD.to_id OR NEW.body <> OLD.body THEN
    RAISE EXCEPTION 'only status and reply can change';
  END IF;
  NEW.updated_at := now();
  RETURN NEW;
END $$;
CREATE TRIGGER gentle_requests_guard_trg BEFORE UPDATE ON public.gentle_requests FOR EACH ROW EXECUTE FUNCTION public.gentle_requests_guard();

CREATE OR REPLACE FUNCTION public.gentle_requests_notify()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    PERFORM public._notify_partner('request_new', 'request', NEW.id, left(NEW.body, 80));
  ELSIF NEW.status IS DISTINCT FROM OLD.status OR NEW.reply IS DISTINCT FROM OLD.reply THEN
    PERFORM public._notify_partner('request_' || NEW.status, 'request', NEW.id, left(NEW.body, 80));
  END IF;
  RETURN NEW;
END $$;
REVOKE ALL ON FUNCTION public.gentle_requests_notify() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER gentle_requests_notify_trg AFTER INSERT OR UPDATE ON public.gentle_requests FOR EACH ROW EXECUTE FUNCTION public.gentle_requests_notify();

-- ===== Realtime =====
ALTER PUBLICATION supabase_realtime ADD TABLE public.tasks;
ALTER PUBLICATION supabase_realtime ADD TABLE public.task_lists;
ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;
ALTER PUBLICATION supabase_realtime ADD TABLE public.gentle_requests;
ALTER PUBLICATION supabase_realtime ADD TABLE public.note_comments;
ALTER TABLE public.tasks REPLICA IDENTITY FULL;

