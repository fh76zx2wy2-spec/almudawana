-- All fixtures and changes are rolled back; never contains personal addresses.
BEGIN;
DO $$ DECLARE emails text[]; aid uuid:='11111111-1111-4111-8111-111111111111'; bid uuid:='22222222-2222-4222-8222-222222222222'; BEGIN
 SELECT array_agg(email ORDER BY email) INTO emails FROM public.allowed_emails;
 INSERT INTO auth.users(id,email,email_confirmed_at) VALUES(aid,emails[1],now()),(bid,emails[2],now());
 BEGIN INSERT INTO auth.users(id,email,email_confirmed_at) VALUES('33333333-3333-4333-8333-333333333333','blocked@example.invalid',now()); RAISE EXCEPTION 'third signup permitted'; EXCEPTION WHEN OTHERS THEN IF SQLERRM NOT LIKE '%email_not_allowed%' THEN RAISE; END IF; END;
END $$;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
INSERT INTO public.notes(id,title,body) VALUES('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa1','private A','secret A');
INSERT INTO public.notes(id,title,body,is_shared,status) VALUES('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa2','shared A','shared',true,'published'),('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa3','draft A','draft',true,'draft');
INSERT INTO public.note_comments(note_id,body) VALUES('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa1','private comment');
INSERT INTO public.task_lists(id,name) VALUES('bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbb1','private list');
INSERT INTO public.task_lists(id,name,is_shared) VALUES('bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbb2','shared list',true);
INSERT INTO public.tasks(id,list_id,title) VALUES('cccccccc-cccc-4ccc-8ccc-ccccccccccc1','bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbb1','private task'),('cccccccc-cccc-4ccc-8ccc-ccccccccccc2','bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbb2','shared task');
SELECT set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
DO $$ DECLARE c int; BEGIN
 SELECT count(*) INTO c FROM public.notes; IF c<>1 THEN RAISE EXCEPTION 'private or draft leak: %',c; END IF;
 SELECT count(*) INTO c FROM public.note_comments; IF c<>0 THEN RAISE EXCEPTION 'comment leak'; END IF;
 SELECT count(*) INTO c FROM public.tasks; IF c<>1 THEN RAISE EXCEPTION 'task leak'; END IF;
 UPDATE public.notes SET title='hijack' WHERE id='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa2'; GET DIAGNOSTICS c=ROW_COUNT; IF c<>0 THEN RAISE EXCEPTION 'partner edited note'; END IF;
 BEGIN INSERT INTO public.note_comments(note_id,body) VALUES('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa1','probe'); RAISE EXCEPTION 'private comment insert permitted'; EXCEPTION WHEN insufficient_privilege THEN NULL; END;
 BEGIN INSERT INTO public.notes(owner_id,title) VALUES('11111111-1111-4111-8111-111111111111','forged'); RAISE EXCEPTION 'owner spoof permitted'; EXCEPTION WHEN insufficient_privilege THEN NULL; END;
 BEGIN UPDATE public.notes SET owner_id='22222222-2222-4222-8222-222222222222' WHERE id='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa2'; GET DIAGNOSTICS c=ROW_COUNT; IF c<>0 THEN RAISE EXCEPTION 'ownership hijack'; END IF; END;
END $$;
DO $$ DECLARE c int; BEGIN
 UPDATE public.tasks SET title='hijack' WHERE id='cccccccc-cccc-4ccc-8ccc-ccccccccccc1'; GET DIAGNOSTICS c=ROW_COUNT; IF c<>0 THEN RAISE EXCEPTION 'private task modified'; END IF;
 BEGIN UPDATE public.notifications SET entity_title='forged'; RAISE EXCEPTION 'notification mutation permitted'; EXCEPTION WHEN insufficient_privilege THEN NULL; END;
 BEGIN INSERT INTO public.tasks(list_id,title) VALUES('bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbb1','probe'); RAISE EXCEPTION 'private task insert permitted'; EXCEPTION WHEN insufficient_privilege THEN NULL; END;
END $$;
UPDATE public.tasks SET is_done=true WHERE id='cccccccc-cccc-4ccc-8ccc-ccccccccccc2';
INSERT INTO public.note_comments(note_id,body) VALUES('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa2','allowed comment');
INSERT INTO public.notes(id,title,body) VALUES('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa4','private B','secret B');
SELECT set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
DO $$ BEGIN
 IF EXISTS(SELECT 1 FROM public.notes WHERE id='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa4') THEN RAISE EXCEPTION 'reverse privacy leak'; END IF;
 IF NOT EXISTS(SELECT 1 FROM public.tasks WHERE id='cccccccc-cccc-4ccc-8ccc-ccccccccccc2' AND is_done) THEN RAISE EXCEPTION 'shared task not updated'; END IF;
END $$;
UPDATE public.notes SET is_shared=false WHERE id='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa2';
SELECT set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
DO $$ BEGIN
 IF EXISTS(SELECT 1 FROM public.notes WHERE owner_id<>auth.uid()) THEN RAISE EXCEPTION 'unshare leak'; END IF;
 IF EXISTS(SELECT 1 FROM public.note_comments) THEN RAISE EXCEPTION 'unshared comment leak'; END IF;
 IF EXISTS(SELECT 1 FROM public.notifications WHERE entity_id='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa2') THEN RAISE EXCEPTION 'notification leak after unshare'; END IF;
END $$;
SELECT set_config('request.jwt.claim.sub','33333333-3333-4333-8333-333333333333',true);
DO $$ BEGIN
 IF EXISTS(SELECT 1 FROM public.notes) THEN RAISE EXCEPTION 'outsider reads notes'; END IF;
 BEGIN INSERT INTO public.notes(title) VALUES('outsider'); RAISE EXCEPTION 'outsider writes'; EXCEPTION WHEN insufficient_privilege THEN NULL; END;
END $$;
RESET ROLE;
ROLLBACK;
SELECT 'RLS privacy suite passed; fixtures rolled back' AS result;
